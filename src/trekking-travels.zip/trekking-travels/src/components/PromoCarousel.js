import React from 'react';
import { Carousel, Container, Row, Col, Button, Card } from 'react-bootstrap';
import { FaStar, FaMapMarkerAlt, FaClock, FaUsers } from 'react-icons/fa';
import './PromoCarousel.css';

const PromoCarousel = () => {
  const promoPackages = [
    {
      id: 1,
      title: "Everest Base Camp Trek",
      location: "Nepal",
      duration: "14 Days",
      groupSize: "Max 12",
      price: "$1,299",
      originalPrice: "$1,599",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      description: "Experience the ultimate adventure to the base of the world's highest peak."
    },
    {
      id: 2,
      title: "Inca Trail to Machu Picchu",
      location: "Peru",
      duration: "7 Days",
      groupSize: "Max 16",
      price: "$899",
      originalPrice: "$1,199",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      description: "Walk the ancient path to the lost city of the Incas."
    },
    {
      id: 3,
      title: "Swiss Alps Adventure",
      location: "Switzerland",
      duration: "10 Days",
      groupSize: "Max 15",
      price: "$1,499",
      originalPrice: "$1,899",
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      description: "Discover the stunning beauty of the Swiss Alps."
    },
    {
      id: 4,
      title: "Patagonia Wilderness",
      location: "Argentina",
      duration: "12 Days",
      groupSize: "Max 10",
      price: "$1,799",
      originalPrice: "$2,199",
      rating: 4.6,
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      description: "Explore the untouched wilderness of Patagonia."
    },
    {
      id: 5,
      title: "Himalayan Valley Trek",
      location: "India",
      duration: "9 Days",
      groupSize: "Max 14",
      price: "$799",
      originalPrice: "$1,099",
      rating: 4.5,
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      description: "Journey through the mystical valleys of the Himalayas."
    }
  ];

  return (
    <section className="promo-carousel-section">
      <Container>
        <Row className="justify-content-center">
          <Col lg={8} className="text-center mb-5">
            <h2 className="section-title">Featured Adventure Packages</h2>
            <p className="section-subtitle">
              Discover our most popular trekking experiences with exclusive discounts
            </p>
          </Col>
        </Row>
        
        <Carousel 
          interval={5000} 
          pause="hover"
          className="promo-carousel"
          indicators={true}
          controls={true}
        >
          {promoPackages.map((pkg) => (
            <Carousel.Item key={pkg.id}>
              <div className="carousel-slide">
                <div className="slide-background" style={{ backgroundImage: `url(${pkg.image})` }}>
                  <div className="slide-overlay"></div>
                </div>
                
                <Container className="slide-content">
                  <Row className="justify-content-center">
                    <Col lg={8} md={10}>
                      <Card className="promo-card">
                        <Card.Body className="text-center">
                          <div className="package-badge">
                            <span className="discount">Save ${parseInt(pkg.originalPrice.replace('$', '')) - parseInt(pkg.price.replace('$', ''))}</span>
                          </div>
                          
                          <h3 className="package-title">{pkg.title}</h3>
                          
                          <div className="package-meta">
                            <div className="meta-item">
                              <FaMapMarkerAlt className="meta-icon" />
                              <span>{pkg.location}</span>
                            </div>
                            <div className="meta-item">
                              <FaClock className="meta-icon" />
                              <span>{pkg.duration}</span>
                            </div>
                            <div className="meta-item">
                              <FaUsers className="meta-icon" />
                              <span>{pkg.groupSize}</span>
                            </div>
                          </div>
                          
                          <div className="package-rating">
                            <FaStar className="star-icon" />
                            <span>{pkg.rating}</span>
                            <span className="rating-text">(120+ reviews)</span>
                          </div>
                          
                          <p className="package-description">{pkg.description}</p>
                          
                          <div className="package-pricing">
                            <span className="current-price">{pkg.price}</span>
                            <span className="original-price">{pkg.originalPrice}</span>
                          </div>
                          
                          <Button 
                            variant="primary" 
                            size="lg" 
                            className="book-now-btn"
                          >
                            Book Now
                          </Button>
                        </Card.Body>
                      </Card>
                    </Col>
                  </Row>
                </Container>
              </div>
            </Carousel.Item>
          ))}
        </Carousel>
      </Container>
    </section>
  );
};

export default PromoCarousel; 