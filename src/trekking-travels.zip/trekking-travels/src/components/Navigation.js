import React, { useState, useEffect } from 'react';
import { Navbar, Nav, Container, NavbarBrand, NavbarToggle, NavbarCollapse } from 'react-bootstrap';
import { Link, useLocation } from 'react-router-dom';
import { FaMountain, FaBars } from 'react-icons/fa';
import './Navigation.css';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { to: '/', text: 'Home' },
    { to: '/packages', text: 'Packages' },
    { to: '/about', text: 'About' },
    { to: '/contact', text: 'Contact' }
  ];

  return (
    <Navbar 
      expand="lg" 
      fixed="top" 
      className={`navbar-custom ${isScrolled ? 'scrolled' : ''}`}
      variant="dark"
    >
      <Container>
        <NavbarBrand as={Link} to="/" className="brand-logo">
          <FaMountain className="logo-icon" />
          <span className="brand-text">Trekking Travels</span>
        </NavbarBrand>
        
        <NavbarToggle aria-controls="basic-navbar-nav">
          <FaBars />
        </NavbarToggle>
        
        <NavbarCollapse id="basic-navbar-nav">
          <Nav className="ms-auto">
            {navLinks.map((link) => (
              <Nav.Link 
                key={link.to}
                as={Link} 
                to={link.to}
                className={location.pathname === link.to ? 'active' : ''}
              >
                {link.text}
              </Nav.Link>
            ))}
          </Nav>
        </NavbarCollapse>
      </Container>
    </Navbar>
  );
};

export default Navigation; 