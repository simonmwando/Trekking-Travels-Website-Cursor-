import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { FaPlay, FaArrowRight } from 'react-icons/fa';
import './Hero.css';

const Hero = () => {
  return (
    <section className="hero-section">
      <div className="hero-background">
        <div className="hero-overlay"></div>
      </div>
      
      <Container className="hero-content">
        <Row className="justify-content-center text-center">
          <Col lg={8} md={10}>
            <h1 className="hero-title">
              Discover the World's Most
              <span className="highlight"> Breathtaking</span> Destinations
            </h1>
            
            <p className="hero-subtitle">
              Embark on unforgettable adventures with our expert guides. 
              From mountain peaks to hidden valleys, experience nature like never before.
            </p>
            
            <div className="hero-buttons">
              <Button 
                variant="primary" 
                size="lg" 
                className="cta-button me-3"
                href="#packages"
              >
                Explore Packages
                <FaArrowRight className="ms-2" />
              </Button>
              
              <Button 
                variant="outline-light" 
                size="lg" 
                className="play-button"
              >
                <FaPlay className="me-2" />
                Watch Video
              </Button>
            </div>
            
            <div className="hero-stats">
              <div className="stat-item">
                <h3>500+</h3>
                <p>Happy Travelers</p>
              </div>
              <div className="stat-item">
                <h3>50+</h3>
                <p>Destinations</p>
              </div>
              <div className="stat-item">
                <h3>10+</h3>
                <p>Years Experience</p>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Hero; 