import React from 'react';
import { Container, Row, Col, Nav } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin, FaYoutube, FaMountain } from 'react-icons/fa';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    company: [
      { name: 'About Us', to: '/about' },
      { name: 'Our Team', to: '/team' },
      { name: 'Careers', to: '/careers' },
      { name: 'Press', to: '/press' }
    ],
    services: [
      { name: 'Trekking Tours', to: '/trekking' },
      { name: 'Adventure Packages', to: '/adventure' },
      { name: 'Custom Trips', to: '/custom' },
      { name: 'Group Tours', to: '/groups' }
    ],
    support: [
      { name: 'Help Center', to: '/help' },
      { name: 'Contact Us', to: '/contact' },
      { name: 'Safety Guidelines', to: '/safety' },
      { name: 'Travel Insurance', to: '/insurance' }
    ],
    legal: [
      { name: 'Privacy Policy', to: '/privacy' },
      { name: 'Terms of Service', to: '/terms' },
      { name: 'Cookie Policy', to: '/cookies' },
      { name: 'Refund Policy', to: '/refund' }
    ]
  };

  const socialLinks = [
    { icon: <FaFacebook />, url: 'https://facebook.com', label: 'Facebook' },
    { icon: <FaTwitter />, url: 'https://twitter.com', label: 'Twitter' },
    { icon: <FaInstagram />, url: 'https://instagram.com', label: 'Instagram' },
    { icon: <FaLinkedin />, url: 'https://linkedin.com', label: 'LinkedIn' },
    { icon: <FaYoutube />, url: 'https://youtube.com', label: 'YouTube' }
  ];

  return (
    <footer className="footer">
      <Container>
        <Row className="footer-content">
          <Col lg={4} md={6} className="mb-4">
            <div className="footer-brand">
              <div className="brand-logo">
                <FaMountain className="logo-icon" />
                <span className="brand-text">Trekking Travels</span>
              </div>
              <p className="brand-description">
                Your trusted partner for unforgettable trekking adventures around the world. 
                We specialize in creating authentic, safe, and transformative travel experiences.
              </p>
              <div className="social-links">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="social-link"
                    aria-label={social.label}
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
            </div>
          </Col>
          
          <Col lg={2} md={6} className="mb-4">
            <h5 className="footer-title">Company</h5>
            <Nav className="footer-nav">
              {footerLinks.company.map((link, index) => (
                <Nav.Link key={index} as={Link} to={link.to} className="footer-link">
                  {link.name}
                </Nav.Link>
              ))}
            </Nav>
          </Col>
          
          <Col lg={2} md={6} className="mb-4">
            <h5 className="footer-title">Services</h5>
            <Nav className="footer-nav">
              {footerLinks.services.map((link, index) => (
                <Nav.Link key={index} as={Link} to={link.to} className="footer-link">
                  {link.name}
                </Nav.Link>
              ))}
            </Nav>
          </Col>
          
          <Col lg={2} md={6} className="mb-4">
            <h5 className="footer-title">Support</h5>
            <Nav className="footer-nav">
              {footerLinks.support.map((link, index) => (
                <Nav.Link key={index} as={Link} to={link.to} className="footer-link">
                  {link.name}
                </Nav.Link>
              ))}
            </Nav>
          </Col>
          
          <Col lg={2} md={6} className="mb-4">
            <h5 className="footer-title">Legal</h5>
            <Nav className="footer-nav">
              {footerLinks.legal.map((link, index) => (
                <Nav.Link key={index} as={Link} to={link.to} className="footer-link">
                  {link.name}
                </Nav.Link>
              ))}
            </Nav>
          </Col>
        </Row>
        
        <hr className="footer-divider" />
        
        <Row className="footer-bottom">
          <Col md={6} className="text-center text-md-start">
            <p className="copyright">
              © {currentYear} Trekking Travels. All rights reserved.
            </p>
          </Col>
          <Col md={6} className="text-center text-md-end">
            <p className="footer-note">
              Made with ❤️ for adventure seekers worldwide
            </p>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer; 